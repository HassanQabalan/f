

// Package imports:
import 'package:famous_flutter/components/constants.dart';
import 'package:get/route_manager.dart';

class MyLocale implements Translations {

  @override
  Map<String, Map<String, String>> get keys =>
  {

    "ar": {
      famousApp:"Famous Lives",
      login:"تسجيل الدخول",
      signUp:"تسجيل",
      phoneNumber:"رقم الهاتف",
      resendCode: "أعد إرسال رمز التحقق",
      unhandledError: "خطأ غير معروف",
      sentTheCodeVerification:"لقد أرسلنا كود التحقق إلى رقم هاتفك",
      errorHappensWhenSendVerificationCode:"حدث خطأ أثناء إرسال كود التحقق",
      confirm:"تأكيد",
      createAnAccount:"Create an account",
      noHaveAccount:"Don't have an account ?",
      groups:"Groups",
      forgetPassword:"Forget Password ?",
      passwordField:"Password",
      emailField:"Email",
      loginSuccessfully:"Login Successfully"
    },
   "en":{
     famousApp:"Famous Lives",
     login:"Login",
     signUp:"Sign up",
     phoneNumber:"Phone",
     resendCode:"Resend verification code",
     unhandledError:"Unhandled Error",
     sentTheCodeVerification:"We sent SMS to your phone number",
     errorHappensWhenSendVerificationCode:"Error happens through send verification code",
     confirm:"Confirm",
     createAnAccount:"Create an account",
     noHaveAccount:"Don't have an account ?",
     groups:"Groups",
     forgetPassword:"Forget Password ?",
     passwordField:"Password",
     emailField:"Email",
     loginSuccessfully:"Login Successfully"
   },
  };
}