import 'package:famous_flutter/bloc_ovserver.dart';
import 'package:famous_flutter/layout/cubit/cubit.dart';
import 'package:famous_flutter/layout/cubit/states.dart';
import 'package:famous_flutter/shared/cache_helper.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get/get.dart';

import 'components/constants.dart';
import 'locale/locale.dart';
import 'locale/localeController.dart';
import 'modules/login/cubit/cubit.dart';
import 'modules/login/login_screen.dart';
import 'modules/register/cubit/cubit.dart';
import 'package:firebase_core/firebase_core.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await CacheHelper.init();
  Firebase.initializeApp();
  Bloc.observer=AppBlocObserver();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    MyLocaleController controllerLang= Get.put(MyLocaleController());
    return MultiBlocProvider(
      providers: [
        BlocProvider(create: (BuildContext context) => FamousCubit()),
        BlocProvider(create: (BuildContext context) => RegisterUserCubit()),
        BlocProvider(create: (BuildContext context) => LoginUserCubit()),
      ],
      child: BlocConsumer<FamousCubit, FamousStates>(
        listener: (context, state) {

        },
        builder: (context, state) {
          return GetMaterialApp(
            debugShowCheckedModeBanner: false,
            title: famousApp.tr,
            locale: controllerLang.initialLang,
            translations: MyLocale(),
            home: LoginUser()
          );
        },
      ),
    );
  }
}