import 'package:bloc/bloc.dart';
import 'package:famous_flutter/layout/cubit/states.dart';
import 'package:famous_flutter/models/group_model.dart';
import 'package:famous_flutter/shared/dio.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get/get.dart';

import '../../components/api_end_points.dart';
import '../../components/constants.dart';

class FamousCubit extends Cubit<FamousStates> {
  FamousCubit() : super(FamousInitialState());

  static FamousCubit get(context) => BlocProvider.of(context);


  List<GroupModel> listOfGroups=[];
  Future<void> getGroups() async {
    emit(GetGroupsLoadingState());
    try {
      await Api.get("$apiUrl/$getGroupsEndpoint/1", ).then((value) {
        print("${value.data['groups']}");
         value.data['groups'].forEach((group){
           listOfGroups.add(GroupModel.fromJson(group));
         });
        emit(GetGroupsSuccessState());
      });
    } catch (error) {
      print(error.toString());
      emit(GetGroupsErrorState());
    }
  }
}