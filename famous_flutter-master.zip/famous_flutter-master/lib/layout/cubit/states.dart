abstract class FamousStates {}

class FamousInitialState extends FamousStates {}

class GetGroupsLoadingState extends FamousStates {}

class GetGroupsSuccessState extends FamousStates {}

class GetGroupsErrorState extends FamousStates {}