import 'package:flutter/material.dart';

class FamousLayout extends StatelessWidget {
  const FamousLayout({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.amber,
    );
  }
}
