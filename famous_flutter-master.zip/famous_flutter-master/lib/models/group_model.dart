class GroupModel{
  late String id;
  late String name;

  GroupModel.fromJson(Map<String, dynamic> json){
    id=json['_id'];
    name=json["name"];
  }
}