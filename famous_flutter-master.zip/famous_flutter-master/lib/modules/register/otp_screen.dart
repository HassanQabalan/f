import 'package:famous_flutter/components/constants.dart';
import 'package:famous_flutter/components/widgets.dart';
import 'package:famous_flutter/modules/login/login_screen.dart';
import 'package:famous_flutter/modules/register/cubit/cubit.dart';
import 'package:famous_flutter/modules/register/cubit/states.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get/get.dart';
import 'package:pinput/pinput.dart';

class OtpScreen extends StatelessWidget {
  final String phone;
  final String name;
  final String password;
  final String email;
  OtpScreen({Key? key, required this.phone, required this.name, required this.password, required this.email}) : super(key: key);

  String code="";

  @override
  Widget build(BuildContext context) {
    final cubit= RegisterUserCubit.get(context);
    return  BlocConsumer<RegisterUserCubit,RegisterUserStates>(
      listener: (context, state) {

      },
      builder: (context, state) {
        return Scaffold(
          body: SingleChildScrollView(
            child: Column(
              children: [
                SizedBox(
                  height: 10,
                ),
                Column(
                  children: [
                    Center(
                      child: Container(
                        height: 200,
                        decoration: const BoxDecoration(
                          image: DecorationImage(
                            image: AssetImage(logoWithEmptyBackground),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 50,
                    ),
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Text(
                          sentTheCodeVerification.tr,
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            wordSpacing: 5,
                            color: Color(0xff2f2e2d),
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 50,
                ),
                Center(
                  child: Pinput(
                    length: 6,
                    onCompleted: (pin) {
                      code=pin;
                      cubit.submitOTP(code);
                      showToast("success", ToastStates.SUCCESS);
                    },
                  )
                ),
                SizedBox(
                  height: 50,
                ),
                if(cubit.responseOtp)
                Center(
                  child: ElevatedButton(
                    child: Text(confirm.tr,
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                          color: Color(0xffeec163),
                        )),
                    onPressed: () {
                      cubit.registerUser(phone: phone,
                          password: password,
                          name: name,
                          email: email).whenComplete(() {
                        if(cubit.responseRegister[success]) {
                          showToast("Register Success", ToastStates.SUCCESS);
                          navigatePushAndRemoveUntil(context, LoginUser());
                        }else{
                          showToast(cubit.responseRegister[msg], ToastStates.ERROR);
                        }
                      });
                    },
                    style: ElevatedButton.styleFrom(
                        primary: Color(0xff2f2e2d),
                        padding:
                        EdgeInsets.symmetric(horizontal: 80, vertical: 12),
                        textStyle: TextStyle()),
                  ),
                ),
                SizedBox(
                  height: 50,
                ),
                Center(
                  child: TextButton(
                    onPressed: () {
                      cubit.verifyPhoneNumber(phone);
                    },
                    child: Text(
                      resendCode.tr,
                      style: const TextStyle(
                        decorationColor: Colors.black,
                        decoration: TextDecoration.underline,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 113, 113, 113),
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
