import 'package:bloc/bloc.dart';
import 'package:famous_flutter/components/widgets.dart';
import 'package:famous_flutter/modules/register/cubit/states.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get/get.dart';
import '../../../components/api_end_points.dart';
import '../../../components/constants.dart';
import '../../../shared/dio.dart';

class RegisterUserCubit extends Cubit<RegisterUserStates> {
  RegisterUserCubit() : super(RegisterUserInitialState());

  static RegisterUserCubit get(context) => BlocProvider.of(context);

  late dynamic responseRegister;
  
  Future<void> registerUser({
    required String phone,
    required String password,
    required String name,
    required String email
  }) async {
    emit(RegisterUserLoadingState());
    try {
      await Api.post("$apiUrl/$registerUserEndPoint", data: {
        "phone": phone,
        "password": password,
        "email": email,
        "name": name
      }).then((value) {
        responseRegister =  value.data;
        responseOtp=false; // for clear data to be as default
        emit(RegisterUserSuccessState());
      });
    } catch (error) {
      responseRegister = {success: false, msg: unhandledError.tr};
      emit(RegisterUserErrorState());
    }
  }

  String? _verificationId;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  bool resendCode=false;

  Future<void> verifyPhoneNumber(String phoneNumber) async {
    emit(SendOTPLoadingState());
    await _auth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      verificationCompleted: (PhoneAuthCredential credential) async {
      },
      verificationFailed: (FirebaseAuthException e) {
        showToast(errorHappensWhenSendVerificationCode.tr, ToastStates.ERROR);
      },
      codeSent: (String verificationId, int? resendToken) async {
        _verificationId=verificationId;
        emit(SendOTPSuccessState());
      },
      codeAutoRetrievalTimeout: (String verificationId) {
        _verificationId=verificationId;
        emit(SendOTPErrorState());
      },
      timeout: const Duration(seconds: 120)
    );
  }

  bool responseOtp = false;

  void submitOTP(String smsCode) async {
    emit(SendOTPLoadingState());
    try {
      PhoneAuthCredential credential = PhoneAuthProvider.credential(
        verificationId: _verificationId!,
        smsCode: smsCode,
      );
      final user = await _auth.signInWithCredential(credential);
      if(user.user!=null){
        responseOtp=true;
        emit(SendOTPSuccessState());
      }else{
        emit(SendOTPErrorState());
      }
    } catch (e) {
      emit(SendOTPErrorState());
      showToast(unhandledError.tr, ToastStates.ERROR);
    }
  }

}