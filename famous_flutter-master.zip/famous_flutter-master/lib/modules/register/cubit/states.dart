abstract class RegisterUserStates {}

class RegisterUserInitialState extends RegisterUserStates {}

class RegisterUserLoadingState extends RegisterUserStates {}

class RegisterUserSuccessState extends RegisterUserStates {}

class RegisterUserErrorState extends RegisterUserStates {}

class SendOTPLoadingState extends RegisterUserStates {}

class SendOTPSuccessState extends RegisterUserStates {}

class SendOTPErrorState extends RegisterUserStates {}