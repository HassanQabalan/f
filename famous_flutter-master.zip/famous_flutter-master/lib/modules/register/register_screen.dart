import 'package:famous_flutter/components/constants.dart';
import 'package:famous_flutter/components/widgets.dart';
import 'package:famous_flutter/modules/login/login_screen.dart';
import 'package:famous_flutter/modules/register/cubit/cubit.dart';
import 'package:famous_flutter/modules/register/cubit/states.dart';
import 'package:famous_flutter/modules/register/otp_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get/get.dart';
import 'package:intl_phone_field/intl_phone_field.dart';

class RegisterUser extends StatelessWidget {
  RegisterUser({Key? key}) : super(key: key);
  TextEditingController nameController=TextEditingController();
  TextEditingController phoneController=TextEditingController();
  TextEditingController emailController=TextEditingController();
  TextEditingController passwordController=TextEditingController();
  String countryCode="";

  @override
  Widget build(BuildContext context) {
    final cubit= RegisterUserCubit.get(context);
    return BlocConsumer<RegisterUserCubit, RegisterUserStates>(
      listener: (context, state) {

      },
      builder: (context, state) {
        return Scaffold(
          backgroundColor: Colors.white,
          body: SingleChildScrollView(
            child: SafeArea(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Center(
                      child: Image.asset(
                        assetImageLogo,
                        scale: 2,
                        fit: BoxFit.cover,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 40, right: 40, bottom: 20),
                      child: Container(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Name",
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            TextFormField(
                              controller: nameController,
                              decoration: InputDecoration(focusColor: Colors.black),
                            ),
                            SizedBox(
                              height: 15,
                            ),
                            Text(
                              "Email",
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            TextFormField(
                              controller: emailController,
                              decoration: InputDecoration(focusColor: Colors.black),
                            ),
                            SizedBox(
                              height: 15,
                            ),
                            Row(
                              children: [
                                Text(
                                  "Phone",
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                            IntlPhoneField(
                              decoration: InputDecoration(focusColor: Colors.black),
                              onChanged: (value) {
                                phoneController.text="${value.countryCode}${value.number}";
                              },
                            ),
                            SizedBox(
                              height: 15,
                            ),
                            Row(
                              children: [
                                Text(
                                  "Password",
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                            TextFormField(
                              controller: passwordController,
                              decoration: InputDecoration(focusColor: Colors.black),
                            ),
                            SizedBox(
                              height: 30,
                            ),
                            Center(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceAround,
                                children: [
                                  Expanded(
                                    flex: 2,
                                    child: ElevatedButton(
                                      child: Text(signUp.tr,
                                          style: TextStyle(
                                            color: Color(0xffeec163),
                                          )),
                                      onPressed: () {
                                        cubit.verifyPhoneNumber(phoneController.text).whenComplete(()
                                        => navigateTo(context, OtpScreen(name: nameController.text,
                                            phone: phoneController.text,
                                            email: emailController.text,
                                            password: passwordController.text
                                        )));
                                      },
                                      style: ElevatedButton.styleFrom(
                                          primary: Color(0xff2f2e2d),
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 30, vertical: 12),
                                          textStyle: TextStyle()),
                                    ),
                                  ),
                                  SizedBox(width: 10,),
                                  Expanded(
                                    child: ElevatedButton(
                                      child: Text(login.tr,
                                          style: TextStyle(
                                            color: primaryColor,
                                          )),
                                      onPressed: () {
                                        navigatePushReplacement(context, LoginUser());
                                      },
                                      style: ElevatedButton.styleFrom(
                                          primary: secondColor,
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 30, vertical: 12),
                                          textStyle: TextStyle()),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                )),
          ),
        );
      },
    );
  }
}