import 'package:famous_flutter/layout/cubit/cubit.dart';
import 'package:famous_flutter/layout/cubit/states.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get/get.dart';

import '../../components/constants.dart';



class GroupsScreen extends StatelessWidget {
  const GroupsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit= FamousCubit.get(context);
    return BlocConsumer<FamousCubit,FamousStates>(
      listener: (context, state) {

      },
      builder: (context, state) {
        return Scaffold(
            backgroundColor: primaryColor,
            appBar: AppBar(
              centerTitle: true,
              title: Text(groups.tr),
              backgroundColor: primaryColor,
            ),
            body: state is GetGroupsLoadingState?
            const Center(child: CircularProgressIndicator(),):
            Padding(
              padding: const EdgeInsets.only(top: 20, left: 8, right: 8),
              child: GridView.count(
                  crossAxisCount: 2,
                  mainAxisSpacing: 5,
                  scrollDirection: Axis.vertical,
                  children: List.generate(cubit.listOfGroups.length, (index) => Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        Container(
                          decoration: BoxDecoration(
                              image: DecorationImage(
                                image: AssetImage("assets/images/FAMOUS.png"),
                                fit: BoxFit.cover,
                              ),
                              color: Colors.red,
                              borderRadius:
                              BorderRadius.all(Radius.circular(20))),
                          height: 150,
                          width: 120,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                cubit.listOfGroups[index].name,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    color: Color(0xffeec163),
                                    fontSize: 16,
                                    fontWeight: FontWeight.w700),
                              ),
                            ],
                          ),
                        )
                      ]))
              ),
            ));
      },

    );
  }
}