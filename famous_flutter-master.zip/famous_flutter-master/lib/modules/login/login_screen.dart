import 'package:famous_flutter/components/widgets.dart';
import 'package:famous_flutter/layout/cubit/cubit.dart';
import 'package:famous_flutter/modules/groups/home_groups.dart';
import 'package:famous_flutter/modules/login/cubit/cubit.dart';
import 'package:famous_flutter/modules/login/cubit/states.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get/get.dart';

import '../../components/constants.dart';
import '../register/register_screen.dart';

class LoginUser extends StatelessWidget {
   LoginUser({Key? key}) : super(key: key);

  TextEditingController emailController=TextEditingController();
  TextEditingController passwordController=TextEditingController();

  @override
  Widget build(BuildContext context) {
    final cubit= LoginUserCubit.get(context);
    return BlocConsumer<LoginUserCubit,LoginUserStates>(
      listener: (context, state) {
      },
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            backgroundColor: Colors.white,
            body: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Image.asset(
                      assetImageLogo,
                      scale: 2,
                      fit: BoxFit.cover,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 40, right: 40, bottom: 20),
                    child: Container(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            emailField.tr,
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          TextFormField(
                            controller: emailController,
                            decoration: InputDecoration(),
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          Text(
                            passwordField.tr,
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          TextFormField(
                            controller: passwordController,
                            decoration: InputDecoration(),
                          ),
                          SizedBox(height: 10,),
                          Center(
                            child: TextButton(
                                onPressed: () {
                                },
                                child: Text(
                                  forgetPassword.tr,
                                  style: TextStyle(color: Colors.black),
                                )),
                          ),
                          Center(
                            child: ElevatedButton(
                              child: Text(login.tr,
                                  style: TextStyle(
                                    color: secondColor,
                                  )),
                              onPressed: () {
                                cubit.loginUser(email: emailController.text, password: passwordController.text).whenComplete(() {
                                  if(cubit.responseLogin[success]==true){
                                    FamousCubit.get(context).getGroups();
                                    navigatePushAndRemoveUntil(context, GroupsScreen());
                                    showToast(loginSuccessfully.tr, ToastStates.SUCCESS);
                                  }else{
                                    showToast(cubit.responseLogin[msg], ToastStates.ERROR);
                                  }
                                });
                              },
                              style: ElevatedButton.styleFrom(
                                  primary: primaryColor,
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 50, vertical: 12),
                                  textStyle: TextStyle()),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 50,
                  ),
                  Center(
                    child: Column(
                      children: [
                        Text(noHaveAccount.tr),
                        TextButton(
                            onPressed: () {
                              navigatePushReplacement(context, RegisterUser());
                            },
                            child: Text(
                              createAnAccount.tr,
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 15,
                                  fontWeight: FontWeight.w600),
                            ))
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        );
      }
    );
  }
}