abstract class LoginUserStates {}

class LoginUserInitialState extends LoginUserStates {}

class LoginUserLoadingState extends LoginUserStates {}

class LoginUserSuccessState extends LoginUserStates {}

class LoginUserErrorState extends LoginUserStates {}