import 'dart:convert';

import 'package:bloc/bloc.dart';
import 'package:dio/dio.dart';
import 'package:famous_flutter/components/constants.dart';
import 'package:famous_flutter/modules/login/cubit/states.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get/get.dart';

import '../../../components/api_end_points.dart';
import '../../../shared/dio.dart';

class LoginUserCubit extends Cubit<LoginUserStates> {
  LoginUserCubit() : super(LoginUserInitialState());

  static LoginUserCubit get(context) => BlocProvider.of(context);

  late dynamic responseLogin;

  Future<void> loginUser(
      {required String email, required String password}) async {
    emit(LoginUserLoadingState());
    try {
     await Api.post("$apiUrl/$loginUserEndPoint", data: {
        "email": email,
        "password": password
      }).then((value) {
        responseLogin = value.data;
        emit(LoginUserSuccessState());
      });
    } catch (error) {
      emit(LoginUserErrorState());
      responseLogin = {success: false, msg: unhandledError.tr};
    }
  }
}