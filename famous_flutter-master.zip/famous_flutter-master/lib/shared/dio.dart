import 'package:dio/dio.dart';

class Api {
  static final Dio _dio = Dio(); // Create a static Dio instance

  static Future<Response> get(String url, {Map<String, dynamic>? queryParameters}) async {
    try {
      final response = await _dio.get(url, queryParameters: queryParameters);
      return response;
    } catch (e) {
      // Handle errors here
      throw e;
    }
  }

  static Future<Response> post(String url, {dynamic data}) async {
    try {
      final response = await _dio.post(url, data: data);
      return response;
    } catch (e) {
      // Handle errors here
      print(e);
      throw e;
    }
  }

}


