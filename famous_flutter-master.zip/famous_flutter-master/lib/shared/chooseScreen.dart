import 'package:famous_flutter/shared/cache_helper.dart';
import 'package:flutter/material.dart';

class InitialScreen {
  static Future<Widget> getInitialScreen() async {
    await CacheHelper.init();
    final token = CacheHelper.getData(key: 'token');
    final isAdmin = CacheHelper.getData(key: 'isFamous') ?? false;

    if (token != null) {
      if (isAdmin) {
        // Navigate to the admin screen
        return Container();
      } else {
        // Navigate to the user screen
        return Container();
      }
    } else {
      // Navigate to the login screen
      return Container();
    }
  }
}