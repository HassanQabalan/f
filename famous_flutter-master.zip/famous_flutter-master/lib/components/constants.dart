import 'dart:ui';

const String apiUrl = "https://famous-api.vercel.app";
const String famousApp="Famous App";
final Color primaryColor =  Color(0xff2f2e2d);
final Color secondColor = Color(0xffeec163);
final Color boxDecCont = Color.fromARGB(255, 236, 234, 234);

const String login="Log In";
const String signUp="Sign up";
const String phoneNumber="Phone";
const String success="success";
const String unhandledError="Unhandled Error";
const String forgetPassword="Forget password?";
const String passwordField="Password";
const String emailField="Email";
const String loginSuccessfully="Login Successfully";
const String msg="msg";
const String groups="Groups";
const String resendCode="Resend verification code";
const String sentTheCodeVerification="We sent SMS to your phone";
const String errorHappensWhenSendVerificationCode= "Error happens when send verification code";
const String confirm="Confirm";
const String createAnAccount="Create an account";
const String noHaveAccount="Don't have an account ?";
const String assetImageLogo = "assets/images/FAMOUS.png";
const String logoWithEmptyBackground = "assets/images/famousblack.png";


