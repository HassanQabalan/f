const String loginUserEndPoint="loginUser";
const String registerUserEndPoint="registerUser";
const String getGroupsEndpoint="getGroups";