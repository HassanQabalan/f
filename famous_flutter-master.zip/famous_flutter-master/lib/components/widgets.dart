import 'dart:io';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

Widget defaultAppBar({
  required BuildContext context,
  String? title,
  List<Widget>? actions,
}) =>
    AppBar(
      leading: IconButton(
        onPressed: () {
          Navigator.pop(context);
        },
        icon: const Icon(
          Icons.arrow_back,
        ),
      ),
      titleSpacing: 5.0,
      title: Text(
        title!,
      ),
      actions: actions,
    );

Widget defaultTextButton({
  required function,
  required String text,
}) =>
    TextButton(
      onPressed: function,
      child: Text(
        text,
        style: const TextStyle(fontSize: 10),
      ),
    );

// Widget defaultButton({
//   double width = double.infinity,
//   Color? background = darkBlueColor,
//   bool isUpperCase = false,
//   double radius = 10.0,
//   required function,
//   required String text,
//   bool innerShadow=false,
//   bool white=false,
//   widthDevice=530,
//   double fontSize=16
// }) =>
//     Container(
//       clipBehavior: Clip.antiAliasWithSaveLayer,
//       decoration: BoxDecoration(
//         boxShadow:innerShadow? [
//           BoxShadow(
//             color: Color(0xff0e3a5d),
//           ),
//           BoxShadow(
//             color: darkBlueColor,
//             spreadRadius: 1,
//             blurRadius: 5,
//             offset: Offset(0, 4),
//           )
//         ]:[],
//       ),
//       child: MaterialButton(
//         onPressed: function,
//         minWidth: width,
//         elevation: 10,
//
//         height: widthDevice>530?65:50.0,
//         shape: RoundedRectangleBorder(
//           side: BorderSide(color: white?Colors.grey:Color(0xFF0D3781)),
//           borderRadius: BorderRadius.circular(
//             radius,
//           ),
//         ),
//         color:  background,
//         child: Text(
//           isUpperCase ? text.toUpperCase() : text,
//           style: white? TextStyle(
//               color: Colors.black, fontSize: fontSize, fontWeight: FontWeight.w500):  TextStyle(
//               color: Colors.white, fontSize: fontSize, fontWeight: FontWeight.w600),
//         ),
//       ),
//     );

void navigatePushReplacement(context, widget) => Navigator.pushReplacement(
  context,
  MaterialPageRoute(builder: (context) => widget),
);

void navigatePushAndRemoveUntil(context, widget) =>
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (context) => widget),
          (route) => false,
    );

void navigateTo(context, widget) => Navigator.push(
  context,
  MaterialPageRoute(
    builder: (context) => widget,
  ),
);

enum ToastStates { SUCCESS, ERROR, WARNING }

Color chooseToastColor(ToastStates state) {
  Color color;

  switch (state) {
    case ToastStates.SUCCESS:
      color = Colors.black54;

      break;

    case ToastStates.ERROR:
      color = Colors.red;

      break;

    case ToastStates.WARNING:
      color = Colors.amber;

      break;
  }

  return color;
}

Future<bool?> showToast(String msg, ToastStates state) =>
    Fluttertoast.showToast(
        msg: msg,
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.SNACKBAR,
        timeInSecForIosWeb: 3,
        backgroundColor: chooseToastColor(state),
        textColor: Colors.white,
        fontSize: 16.0);

Widget myDivider() => Container(
  width: double.infinity,
  height: 1.0,
  color: Colors.grey[300],
);

String getOS() {
  return Platform.operatingSystem;
}

Widget defaultActiveStatusCircle({required Color color, double padding = 5.0, double width = 18.0,  double height = 15.0, double rightPadding = 0.0}) {
  return Container(
    height: height,
    width: width,
    margin: EdgeInsets.only(bottom: padding , right: rightPadding ),
    decoration: BoxDecoration(
      color: color,
      shape: BoxShape.circle,
      border: Border.all(
        color: Colors.white,
        width: 0.8,
      ),
    ),
  );
}