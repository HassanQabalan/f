package com.zoudne.famous

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
